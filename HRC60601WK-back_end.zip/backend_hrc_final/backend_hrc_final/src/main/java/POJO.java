public class POJO { // Declare the class
          private int sl_no; // Declare the sl_no variable
          private String business_code; // Declare the business_code variable
          private Integer cust_number; // Declare the cust_number variable
          private String clear_date; // Declare the clear_date variable
          private int buisness_year; // Declare the buisness_year variable
          private String doc_id; // Declare the doc_id variable
          private String posting_date; // Declare the posting_date variable
          private String document_create_date; // Declare the document_create_date variable
          private String document_create_date1; // Declare the document_create_date1 variable
          private String due_in_date; // Declare the due_in_date variable
          private String invoice_currency; // Declare the invoice_currency variable
          private String document_type; // Declare the document_type variable
          private int posting_id; // Declare the posting_id variable
          private int area_business; // Declare the area_business variable
          private double total_open_amount; // Declare the total_open_amount variable
          private String baseline_create_date; // Declare the baseline_create_date variable
          private String cust_payment_terms; // Declare the cust_payment_terms variable
          private int invoice_id; // Declare the invoice_id variable
          private int isOpen; // Declare the isOpen variable
          private String aging_bucket; // Declare the aging_bucket variable
          private int is_deleted; // Declare the is_deleted variable
          public int getSl_no() { // Declare the getSl_no method
			return sl_no; // Return the sl_no variable
		}
		public void setSl_no(int sl_no) { // Declare the setSl_no method
			this.sl_no = sl_no; // Set the sl_no variable
		}
		public String getBusiness_code() { //	Declare the getBusiness_code method
			return business_code; // Return the business_code variable
		}
		public void setBusiness_code(String business_code) { // Declare the setBusiness_code method
			this.business_code = business_code; // Set the business_code variable
		}
		
		public Integer getCust_number() { // Declare the getCust_number method
			return cust_number; // Return the cust_number variable
		}
		public void setCust_number(Integer cust_number) { // Declare the setCust_number method
			this.cust_number = cust_number; // Set the cust_number variable
		}
		public String getClear_date() { // Declare the getClear_date method
			return clear_date; // Return the clear_date variable
		}
		public void setClear_date(String clear_date) { // Declare the setClear_date method
			this.clear_date = clear_date; // Set the clear_date variable
		}
		public int getBuisness_year() { // Declare the getBuisness_year method
			return buisness_year; // Return the buisness_year variable
		}
		public void setBuisness_year(int buisness_year) { // Declare the setBuisness_year method
			this.buisness_year = buisness_year; // Set the buisness_year variable
		}
		public String getDoc_id() { // Declare the getDoc_id method
			return doc_id; // Return the doc_id variable
		}
		public void setDoc_id(String doc_id) { // Declare the setDoc_id method
			this.doc_id = doc_id; // Set the doc_id variable
		}
		public String getPosting_date() { // Declare the getPosting_date method
			return posting_date; // Return the posting_date variable
		}
		public void setPosting_date(String posting_date) { // Declare the setPosting_date method
			this.posting_date = posting_date; // Set the posting_date variable
		}
		public String getDocument_create_date() { // Declare the getDocument_create_date method
			return document_create_date; // Return the document_create_date variable
		}
		public void setDocument_create_date(String document_create_date) { // Declare the setDocument_create_date method
			this.document_create_date = document_create_date; // Set the document_create_date variable
		}
		public String getDocument_create_date1() { // Declare the getDocument_create_date1 method
			return document_create_date1; // Return the document_create_date1 variable
		}
		public void setDocument_create_date1(String document_create_date1) { // Declare the setDocument_create_date1 method
			this.document_create_date1 = document_create_date1; // Set the document_create_date1 variable
		}
		public String getDue_in_date() { // Declare the getDue_in_date method
			return due_in_date; // Return the due_in_date variable
		}
		public void setDue_in_date(String due_in_date) { // Declare the setDue_in_date method
			this.due_in_date = due_in_date; // Set the due_in_date variable
		}
		public String getInvoice_currency() { // Declare the getInvoice_currency method
			return invoice_currency; // Return the invoice_currency variable
		}
		public void setInvoice_currency(String invoice_currency) { // Declare the setInvoice_currency method
			this.invoice_currency = invoice_currency; // Set the invoice_currency variable
		}
		public String getDocument_type() { // Declare the getDocument_type method
			return document_type; // Return the document_type variable
		}
		public void setDocument_type(String document_type) { // Declare the setDocument_type method
			this.document_type = document_type; // Set the document_type variable
		}
		public int getPosting_id() { // Declare the getPosting_id method
			return posting_id; // Return the posting_id variable
		}
		public void setPosting_id(int posting_id) { // Declare the setPosting_id method
			this.posting_id = posting_id; // Set the posting_id variable
		}
		public int getArea_business() { // 	Declare the getArea_business method
			return area_business; // Return the area_business variable
		}
		public void setArea_business(int area_business) { // Declare the setArea_business method
			this.area_business = area_business; // Set the area_business variable
		}
		public double getTotal_open_amount() { // Declare the getTotal_open_amount method
			return total_open_amount; // Return the total_open_amount variable
		}
		public void setTotal_open_amount(double total_open_amount) { // Declare the setTotal_open_amount method
			this.total_open_amount = total_open_amount; // Set the total_open_amount variable
		}
		public String getBaseline_create_date() { //  Declare the getBaseline_create_date method
			return baseline_create_date; // Return the baseline_create_date variable
		}
		public void setBaseline_create_date(String baseline_create_date) { // Declare the setBaseline_create_date method
			this.baseline_create_date = baseline_create_date; // Set the baseline_create_date variable
		}
		public String getCust_payment_terms() { // Declare the getCust_payment_terms method
			return cust_payment_terms; // Return the cust_payment_terms variable
		}
		public void setCust_payment_terms(String cust_payment_terms) { // Declare the setCust_payment_terms method
			this.cust_payment_terms = cust_payment_terms; // Set the cust_payment_terms variable
		}
		public int getInvoice_id() { // Declare the getInvoice_id method
			return invoice_id; // Return the invoice_id variable
		}
		public void setInvoice_id(int invoice_id) { // Declare the setInvoice_id method
			this.invoice_id = invoice_id; // Set the invoice_id variable
		}
		public int getIsOpen() { // Declare the getIsOpen method
			return isOpen; // Return the isOpen variable
		}
		public void setIsOpen(int isOpen) { // Declare the setIsOpen method
			this.isOpen = isOpen; // Set the isOpen variable
		}
		public String getAging_bucket() { // Declare the getAging_bucket method
			return aging_bucket; // Return the aging_bucket variable
		}
		public void setAging_bucket(String aging_bucket) { // Declare the setAging_bucket method
			this.aging_bucket = aging_bucket; // Set the aging_bucket variable
		}
		public int getIs_deleted() { // Declare the getIs_deleted method
			return is_deleted; // Return the is_deleted variable
		}
		public void setIs_deleted(int is_deleted) {// Declare the setIs_deleted method
			this.is_deleted = is_deleted; // Set the is_deleted variable
		}
}
	